export class Mezzo {
  tipo: string;
  descrizione: string;
  tariffa: string;
  valutazioneMedia: number;
}
