export class Verdura {

  nome: string;
  descrizione: string;
  prezzo: string;
}
