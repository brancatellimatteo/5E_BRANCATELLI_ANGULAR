import { Verdura } from './dvegetables.model';

export const Verdure: Verdura[] =
[
  {
    nome: "carote",
    descrizione: "arancioni ...a forma di carota",
    prezzo: "10 soldi al kg"
  },
  {
    nome: "zucchine",
    descrizione: "verdi ...a forma di carota ma più larghe in fondo",
    prezzo: "5 soldi al kg"
  },
  {
    nome: "patate",
    descrizione: "gialle decisamente non a forma di carota",
    prezzo: "2 soldi al kg"
  }
]
